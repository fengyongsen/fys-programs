// pages/index/page/page.js
// I coming again  2018.6.5

/*
V1版
1.声音:  背景音乐  答对庆祝声音     OK
2.添加答案功能                    OK
3.添加金币项目： 默认50个金币  
花费= 提示：20金币 答案：10金币； 
获得= 答对 奖励5金币               OK
//code  in 2018-3-14 00:35
//

需要解决问题
3.使用mysql 新的域名空间 腾讯云
4.好友排名功能
5.付款功能： 购买金币  打赏
6.添加广告
V2版
1.多人竞赛模式
*
*/

var eComm = require("./comm.js");//数据文件

var wordLevel;  //单词Level

var coin; //金币

var pageObject = {

  /**
   * 页面的初始数据  
   */
  data: {


  },
  /* 按钮功能 */


  // test: function (e) {  //这是测试按钮

  //   try {
  //     eComm.背景音乐('暂停');

  //   } catch (e) {
  //     // Do something when catch error
  //     console.log(e)
  //   }
  // },

  背景音乐开关: function (e) {

    if (e.detail.value) {
      eComm.播放声音('背景');
    } else {
      wx.pauseBackgroundAudio()
      
    }
  },


  重玩事件: function (e) {

    var that = this;
    wx.showModal({
      title: '真的吗？？？',
      content: '要重新从第一关开始猜起吗？',
      success: function (res) {
        if (res.confirm) {
          // console.log('用户点击确定')
          wordLevel = 0
          try { //保存 level
            wx.setStorageSync('Level', wordLevel);
          } catch (e) {console.log(e)}

          eComm.myAnswer = ['*', '*', '*', '*'];
          var pre = wordLevel / eComm.成语数量 * 100
          that.setData({
            count: wordLevel,
            Percent: pre,
            img: eComm.emoji.img,
            myAnswer: eComm.myAnswer,
            kbWord: eComm.获取键盘文字(wordLevel)
          })
        } else if (res.cancel) {
          // console.log('用户点击取消')
        }
      }
    })

  },

  提示事件: function (e) {
    if (coin >= 20) {
      wx.showModal({
        title: '提示  (金币-20)',
        content: eComm.emoji.hint[wordLevel],
        showCancel: false,

      })
      coin = coin - 20
      wx.setStorageSync('Coin', coin);

      this.setData({
        theCoin: coin
      })
    } else {
      wx.showModal({
        title: '金币不足',
        content: '请购买跟多金币',
        showCancel: true,
        success: function (res) {
          if (res.confirm) {
            // console.log('用户点击确定')
            wx.navigateTo({
              url: 'buyCoin',
            })
          } else if (res.cancel) {
            // console.log('用户点击取消')
          }
        }

      })
    }
  },

  答案事件: function (e) {

    if (coin >= 10) {
      coin = coin - 10
      wx.setStorageSync('Coin', coin);

      eComm.获取答案(wordLevel);

      if (eComm.isRight(e.target.id, wordLevel)) {  //答对
        eComm.播放声音('答对')
        wx.navigateTo({
          url: 'right',
        })
        this.setData({
          count: ++wordLevel,
          myAnswer: eComm.myAnswer,
          kbWord: eComm.获取键盘文字(wordLevel)
        })
      
          wx.setStorageSync('Level', wordLevel);
      
      }
      this.setData({
        myAnswer: eComm.myAnswer,
        theCoin: coin
      });
    } else {
      wx.showModal({
        title: '金币不足 (金币-10)',
        content: '请购买跟多金币',
        showCancel: true,
        success: function (res) {
          if (res.confirm) {
            // console.log('用户点击确定')
            wx.navigateTo({
              url: 'buyCoin',
            })


          } else if (res.cancel) {
            // console.log('用户点击取消')
          }
        }

      })
    }
  },





  键盘事件: function (e) {

    eComm.答错声音();


    if (eComm.isRight(e.target.id, wordLevel)) {  //答对

      coin = coin + 2;
      wx.setStorageSync('Coin', coin);
      eComm.播放声音('答对')
      wx.navigateTo({
        url: 'right',
      })
      this.setData({
        count: ++wordLevel,
        myAnswer: eComm.myAnswer,
        kbWord: eComm.获取键盘文字(wordLevel)
      
      })
      try {
        wx.setStorageSync('Level', wordLevel);
      } catch (e) {
        console.log(e);
      }
    } else {

      this.setData({
        myAnswer: eComm.myAnswer
      });
    }



  },

  取消事件: function (e) {
    eComm.播放声音('取消');
    eComm.myAnswer[e.target.id] = '*';
    this.setData({
      myAnswer: eComm.myAnswer
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {

   // eComm.播放声音('背景');
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
    //wx.setStorageSync('Coin',10)
    try {
      var Level = wx.getStorageSync('Level')
      var Coin =  wx.getStorageSync('Coin')
      if (Level) { wordLevel = Level } else { wordLevel = 0 }
      if (Coin) { coin = Coin } else { coin = 50 } // 默认金币 50
    } catch (e) {
      console.log(e);
    }

    var pre = wordLevel / eComm.成语数量 * 100
    eComm.myAnswer = ['*', '*', '*', '*'];
    this.setData({
      count: wordLevel,
      Percent: pre,
      theCoin: coin,
      img: eComm.emoji.img,
      myAnswer: eComm.myAnswer,
      kbWord: eComm.获取键盘文字(wordLevel)
    })

    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

    return {
      title: '表情猜成语',
      path: 'pages/index/page/play',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }


  }
}


Page(pageObject)