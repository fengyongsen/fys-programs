
var publicRequester = getApp().global.publicRequester;

Page({
  data: {
  },
  onLoad: function () {
    console.log('onLoad');
    var that = this;
    //获取热查症状的分类
    this.getHotSymptomCategorys();
  },
  getHotSymptomCategorys:function(){
    publicRequester.getHotSymptomCategorys(
      function(res){
        console.log(res);
      },function(err){
        console.log("失败了");
      }
    );
  }
})