//工程环境的配置
// 环境类型，0开发版，1内测版，2公开版
 var versionType=0

 module.exports = {
    versionType:versionType
}