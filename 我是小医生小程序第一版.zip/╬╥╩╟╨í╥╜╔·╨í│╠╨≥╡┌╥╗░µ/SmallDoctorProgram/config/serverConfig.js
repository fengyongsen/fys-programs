//服务器地址配置
//跟operateConfig里面versionType有关配置start
var operateConfig = require("operateConfig.js");

var serviceUrls = ["http://192.168.0.49:8089/","http://192.168.0.49:8089/","http://wx.witspring.net/"];

var serviceUrl = serviceUrls[operateConfig.versionType];

//跟operateConfig里面versionType有关配置end

 module.exports = {
    serviceUrl:serviceUrl
}