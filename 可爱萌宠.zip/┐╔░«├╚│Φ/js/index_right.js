/**
 * Created by Administrator on 2017/6/20.
 */
var xflag;
var Time;


window.onload=function turn() {

    var top=parseInt(document.getElementById('right2').style.marginTop);
    var ulh=parseInt(document.getElementById('right2').style.height);
    var top2=parseInt(document.getElementById('right3').style.marginTop);
    var height=150*7;
    top-=1;
    top2-=1;
    document.getElementById('right3').style.marginTop=top2+"px";
    document.getElementById('right2').style.marginTop=top+"px";
    if(top<=-155*4){
        top=500;
        //alert(top2)
        document.getElementById('right2').style.marginTop=top+"px";
    }
    if(top2<=-160*3){
        top=5;

        document.getElementById('right2').style.marginTop=top+"px";
        top2=630;
        document.getElementById('right3').style.marginTop=top2+"px";
    }



}
Time=setInterval("window.onload()",20);

function aa(){
    clearInterval(Time);
}
function bb(){
    Time=setInterval("window.onload()",20);
}
function dd(){
    var top=parseInt(document.getElementById('right2').style.marginTop);
    var top2=parseInt(document.getElementById('right3').style.marginTop);
    top-=60;
    top2-=60;

    document.getElementById('right2').style.marginTop=top+"px";
    document.getElementById('right3').style.marginTop=top2+"px";

}
//Time=setInterval("window.onload()",100);
function cc(){
    var top=parseInt(document.getElementById('right2').style.marginTop);
    var top2=parseInt(document.getElementById('right3').style.marginTop);
    top+=60;
    top2+=60;
    document.getElementById('right2').style.marginTop=top+"px";
    document.getElementById('right3').style.marginTop=top2+"px";
}