/**
 * Created by Ҷ on 2017/6/30.
 */
$(window).scroll(function(){
    //alert("aaa");
    var _top=$(window).scrollTop();
    //document.title=_top;
    if(_top>150){
        $("#menu").addClass("gd");
    }else{
        $("#menu").removeClass("gd");
    }
});

$(document).ready(function(){
    $("#left_bto1").click(function(){
        $("#left_ul1").slideToggle("slow");
        $("#left_ul2").slideUp("slow");
        $("#left_ul3").slideUp("slow");
        $("#left_ul4").slideUp("slow");
    });
    $("#left_bto2").click(function(){
        $("#left_ul2").slideToggle("slow");
        $("#left_ul1").slideUp("slow");
        $("#left_ul3").slideUp("slow");
        $("#left_ul4").slideUp("slow");
    });
    $("#left_bto3").click(function(){
        $("#left_ul3").slideToggle("slow");
        $("#left_ul2").slideUp("slow");
        $("#left_ul1").slideUp("slow");
        $("#left_ul4").slideUp("slow");
    });
    $("#left_bto4").click(function(){
        $("#left_ul4").slideToggle("slow");
        $("#left_ul2").slideUp("slow");
        $("#left_ul3").slideUp("slow");
        $("#left_ul1").slideUp("slow");
    });

    $("#right_text").click(function(){
        var display=$("#right_gif").css("display");
        $("#right_gif").slideToggle("slow");

    if(display=="none"){
        $("#part2_ul_li2").addClass("part2_ul_li2");
        $("#part2_ul_li3").addClass("part2_ul_li3");
    }
        if(display=="block"){
            $("#part2_ul_li2").removeClass("part2_ul_li2");
            $("#part2_ul_li3").removeClass("part2_ul_li3");
        }
    });
});
