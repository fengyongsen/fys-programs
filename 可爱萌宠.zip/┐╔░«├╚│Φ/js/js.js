/**
 * Created by Administrator on 2017/11/17 0017.
 */
var xflag;
var Time;

window.onload=function turn(){
    var left=parseInt(document.getElementById('ul').style.marginLeft);
    var width=parseInt(document.getElementById('ul').style.width);

    if(-left>=width-700||left>=20){
        xflag=!xflag;
    }
    if(xflag){
        left-=1;

    }else{
        left+=1;
    }
    document.getElementById('ul').style.marginLeft=left+"px";

}
Time=setInterval("window.onload()",20);

function start(){
    clearInterval(Time);
}
function stop(){
    Time=setInterval("window.onload()",20);
}